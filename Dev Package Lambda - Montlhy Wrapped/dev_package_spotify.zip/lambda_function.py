import json
import requests

token_url = 'https://accounts.spotify.com/api/token'
clientSecret_64 = "MDVhNDNiZjIxMjQyNGRkMzhjYjIxZTYwYzExZjdiMzI6NmM4MGZkNDBkNmFkNDZkY2FjYTZhMjg3ZTYxMWIxODg="
spotify_token = ""
spotify_user_id = ""

def get_token(code):
    print("> getting token...")
    headers = {
        'Authorization': "Basic " + clientSecret_64,
    }
    
    data = {
        'grant_type': 'authorization_code',
        'code': code,
        'redirect_uri': 'https://38sgfvcwyf.execute-api.us-east-2.amazonaws.com/test/weekly'
    }
    
    response = requests.post(token_url, headers=headers, data=data)
    
    response_json = response.json()
    return response_json
    
def get_user_id(spotify_token):
    print("> getting user id...")
    query = "https://api.spotify.com/v1/me"
    response = requests.get(query, headers={"Content-Type" : "application/json",
                                            "Authorization" : "Bearer {}".format(spotify_token)})
    response_json = response.json()
    spotify_user_id = response_json["id"]
    
    playlist_id = create_playlist()
    return playlist_id
    
def create_playlist():
    print("> creating playlist...")
    query = "https://api.spotify.com/v1/users/{}/playlists".format(spotify_user_id)

    playlist_name = "WeeklyWrapped AWS API"

    body = json.dumps( {"name" : playlist_name,
                        "public" : True,
                        "collaborative" : False,
                        "description" : "Primer calis para crear playlist desde el API usando python"})
    
    response  = requests.post(query, headers={"Content-Type" : "application/json", "Authorization" : "Bearer {}".format(spotify_token)}, data=body)

    response_json = response.json()
    playlist_id = response_json["id"].split(":")[-1]
    ## self.playlist_id = playlist_id
    return playlist_id

def lambda_handler(event, context):
    # TODO implement
    
    parameters = json.dumps(event)
    
    url_parameters = event["queryStringParameters"]
    
    print("> getting code parameter")
    full_token = get_token(url_parameters["code"])
    
    spotify_token = full_token["access_token"]
    refresh_token = full_token["refresh_token"]
    scope = full_token["scope"]
    
    playlist_id = get_user_id()
    print("> Playlist ID: " + playlist_id)
    
    return {
        'statusCode': 200,
        'body': {
            "access_token": access_token,
            "refresh_token": refresh_token,
            "scope": scope
        }
    }
    
    ##return {
    ##    'statusCode': 200,
    ##    'body': json.dumps('Hello from Lambda! 2 ' + path)
    ##}
